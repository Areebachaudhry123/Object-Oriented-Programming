import tkinter as tk
from abc import ABC, abstractmethod
import math

# Abstract base class
class Shape(ABC):
    @abstractmethod
    def area(self):
        pass

    @abstractmethod
    def draw_shape(self, canvas):
        pass
#class of rectangle 
class Rectangle(Shape):
    def __init__(self, width, height):
        self.width = width
        self.height = height

    def area(self):
        return self.width * self.height

    def draw_shape(self, canvas, x, y):
        canvas.create_rectangle(x, y, x + self.width, y + self.height, outline="pink")

# class Circle
class Circle(Shape):
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return math.pi * self.radius**2

    def draw_shape(self, canvas, x, y):
        canvas.create_oval(x - self.radius, y - self.radius,
                            x + self.radius, y + self.radius, outline="yellow")

class Square(Rectangle):
    def __init__(self, side):
        super().__init__(side, side)


class Oval(Circle):
    def __init__(self, radius1, radius2):
        super().__init__(radius1)
        self.radius2 = radius2

    def area(self):
        return math.pi * self.radius 

    def draw_shape(self, canvas, x, y):
        canvas.create_oval(x - self.radius, y - self.radius,
                            x + self.radius, y + self.radius, outline="orange")

a = tk.Tk()
a.title("Shapes Drawing")


canvas = tk.Canvas(a, width=400, height=400, bg="white")
canvas.pack()

rectangle = Rectangle(80, 50)
circle = Circle(30)
square = Square(50)
oval = Oval(40, 20)


rectangle.draw_shape(canvas, 50, 50)
circle.draw_shape(canvas, 150, 150)
square.draw_shape(canvas, 250, 50)
oval.draw_shape(canvas, 350, 150)

shapes = [rectangle, circle, square, oval]
for shape in shapes:
    print(f"Area of {type(shape).__name__}: {shape.area()}")

a.mainloop()
