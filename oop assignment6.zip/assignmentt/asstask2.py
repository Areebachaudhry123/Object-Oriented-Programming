class Person:
    def __init__(self, name, contactno):
        self.name = name
        self.contactno = contactno

    def display_info(self):
        print(f"Name: {self.name}\nContact Number: {self.contactno}")


class Student:
    def __init__(self, department, semester):
        self.department = department
        self.semester = semester

    def display_info(self):
        print(f"Department: {self.department}\nSemester: {self.semester}")


class Teacher:
    def __init__(self, course, officeno):
        self.course = course
        self.officeno = officeno

    def display_info(self):
        print(f"Course: {self.course}\nOffice Number: {self.officeno}")


class TA(Person, Student, Teacher):
    def __init__(self, name, contactno, department, semester, course, officeno):

        Person.__init__(self, name, contactno)
    
        Student.__init__(self, department, semester)
     
        Teacher.__init__(self, course, officeno)

    def display_info(self):
        Person.display_info(self)
        Student.display_info(self)
        Teacher.display_info(self)


S1 = Student("E", 1)
T1 = Teacher("jgjk", 147)
TA1 = TA("jukv", "ugk", "hihk", 2, "Njbhjk", 37)

print("Student Information:")
S1.display_info()
print("\nTeacher Information:")
T1.display_info()
print("\nTA Information:")
TA1.display_info()
