import math

class Vector:
    def __init__(self, *components):
        self.components = tuple(components)

    def __getitem__(self, index): #use of index operator
        return self.components[index]

    def magnitude(self): #function calculating magnitude 
        mag = sum(x ** 2 for x in self.components)
        return math.sqrt(mag)

    def dot_product(self, other): #funcion calculating dot product 
        if len(self.components) != len(other.components):
            raise ValueError("Vectors should have the same dimensions")
        a = 0
        for i in range(len(self.components)):
            a += self[i] * other[i]
        return a

    def __str__(self):
        return f"Vector{self.components}"

#test cases
#two dimensions vectors
a = Vector(3, 4)
b = Vector(1, -2)
dot_product_2d = a.dot_product(b)
magnitude_2d = a.magnitude()
magnitude_2dd = b.magnitude()
print("Two 2D Vectors:")
print(a)
print(b)
print("Dot Product:", dot_product_2d)
print("Magnitude of a:", magnitude_2d)
print("Magnitude of b:", magnitude_2dd)
#three dimensions vectors
a = Vector(1, 2, 3)
b = Vector(-1, 0, 2)
dot_product_3d = a.dot_product(b)
magnitude_3d = a.magnitude()
magnitude_3dd = b.magnitude()
print("\nTwo 3D Vectors:")
print(a)
print(b)
print("Dot Product:", dot_product_3d)
print("Magnitude of a:", magnitude_3d)
print("Magnitude of b:", magnitude_3dd)
#four dimensions vectors
a = Vector(1, 2, 3, 4)
b = Vector(0, -1, -2, -3)
dot_product_4d = a.dot_product(b)
magnitude_4d = a.magnitude()
magnitude_4dd = b.magnitude()
print("\nTwo 4D Vectors:")
print(a)
print(b)
print("Dot Product:", dot_product_4d)
print("Magnitude of a:", magnitude_4d)
print("Magnitude of b:", magnitude_4dd)
#five dimensions vectors
a = Vector(1, 2, 3, 4, 5)
b = Vector(0, -1, -2, -3, -4)
dot_product_5d = a.dot_product(b)
magnitude_5d = a.magnitude()
magnitude_5dd = b.magnitude()
print("\nTwo 5D Vectors:")
print(a)
print(b)
print("Dot Product:", dot_product_5d)
print("Magnitude of a:", magnitude_5d)
print("Magnitude of b:", magnitude_5dd)
